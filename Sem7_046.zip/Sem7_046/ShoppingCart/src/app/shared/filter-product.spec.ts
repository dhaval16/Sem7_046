import { FilterProduct } from './filter-product';

describe('FilterProduct', () => {
  it('should create an instance', () => {
    expect(new FilterProduct()).toBeTruthy();
  });
});
